
function autoRempValide(){
    document.getElementById('name').value = "Nouar"
    document.getElementById('firstname').value = "Rania"
    document.getElementById('date').value = "16/06/1999"
    document.getElementById('pseudo').value = "Noira"
    document.getElementById('pwd').value = "HHHjjjjjKKKK4545"
    document.getElementById('email').value = "laiko@fgzef.com"
}

function autoRempNonValide(){
    document.getElementById('name').value = "Loirette"
    document.getElementById('firstname').value = "Valentin"
    document.getElementById('date').value = "1321/15/1235"
    document.getElementById('pseudo').value = "Noira"
    document.getElementById('pwd').value = "FDSFQfsdfsdf"
    document.getElementById('email').value = "sdvq@vsdsvqd"
}

function checkPwd(){
    var password = document.getElementById('pwd').value;
    if(password == null)
    {
        alert("pwd est null")
    }
    else
        alert("Ton mot de passe est " + password);

    if (/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/.test(password))
    {
        alert("Le mot de passe est bon !")
    }       
    else
        alert("Le mot de passe n'est pas bon !")
}

function checkEmail(){
    var address = document.getElementById('email').value;

    if(/\S+@\S+\.\S+/.test(address)){
        alert("L'adresse email est bonne !")
    }
    else
        alert("L'adresse email n'est pas bonne !")
}

function checkDate(){
    var date = document.getElementById('date').value
    var splitDate = date.split('/')
    var myDate = splitDate[2] + "-" +splitDate[1] + "-" + splitDate[0]
    alert("Ma date est : " + myDate)
    var d = new Date(myDate)
    var myParse = Date.parse(d)
    alert(myParse)
    if(isNaN(myParse)){
        alert("DATE INVALIDE")
    }
    else{
        alert("DATE VALIDE")
    }
    
    // On veut vérifier que la date rentrée est bien valide.
    // Il faut que le nombre de jours soit bon par rapport au mois
    // Et que le numéro du mois soit valide.  
    // Problème : En JS, Date change automatiquement une date du type : 32/01/2001 en 01/02/2001
    // IL FAUT TROUVER UNE SOLUTION !

}

(function(){
    var paragraphe = document.querySelector('.paragraph')
    var div = document.querySelector('#div')
    paragraphe.className = "paragraph blue"
    div.className = "div red"
    div.style.fontSize = "20px"

})()
